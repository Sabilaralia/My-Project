#include <stdio.h>
#include <string.h>

void balikKata(char kata[]){
	int panjang = strlen(kata);
	for(int i = 0; i < panjang/2; i++){
		char temp = kata[i];
		kata[i] = kata[panjang - i - 1];
		kata[panjang - i - 1] = temp;
	}
}

int main(){

	char kata[100];
	scanf("%[^\n]", kata);
	balikKata(kata);
	for(int i = 0; i < strlen(kata); i++){
		if(kata[i] >= 'a' && kata[i] <= 'z'){
			kata[i] -=32;
		} else if(kata[i] >= 'A' && kata[i] <= 'Z'){
			kata[i] += 32;
		}
	}
	printf("Kata yang sudah dibalik dan diubah dengan inversi kapitalisasi: %s\n", kata);


	return 0;
}
//pake /n tiap beres printf

