#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct coordinate {
    char location[100];
    char city[100];
    int price;
    int room;
    int bathroom;
    int carpark;
    char type[100];
    char furnish[100];
};


void displayData(FILE* fp, int rows){ 

    
    if (rows < 0) {
        printf("NOT FOUND! : Number of rows must be non-negative\n");
        return;
    }

    struct coordinate* hotel = (struct coordinate*)malloc(rows * sizeof(struct coordinate));

    if (hotel == NULL) {
        printf("Memory allocation failed.\n");
        return;
    }

    char n;
    int i;
    
    while (n != '\n') {
        n = fgetc(fp);
    }
    
	for (i = 0; i < rows; i++) {
        fscanf(fp, "%[^,],%[^,],%d,%d,%d,%d,%[^,],%[^\n]\n",
               hotel[i].location, hotel[i].city, &hotel[i].price,
               &hotel[i].room, &hotel[i].bathroom, &hotel[i].carpark,
               hotel[i].type, hotel[i].furnish);
    }
    
  printf("| %-20s | %-12s | %-10s | %-5s | %-8s | %-10s | %-11s  | %-12s |\n",
           "Location", "City", "Price", "Rooms", "Bathroom", "Carpark", "Type", "Furnish");

    for (i = 0; i < rows; i++) {
        printf("| %-20s | %-12s | %-10d | %-5d | %-8d | %-10d | %-12s | %-12s |\n",
               hotel[i].location, hotel[i].city, hotel[i].price,
               hotel[i].room, hotel[i].bathroom, hotel[i].carpark,
               hotel[i].type, hotel[i].furnish);
    }
}

void bubblesort(struct coordinate hotel[], int n, const char *column_choice) {
    int i, j;
    struct coordinate temp;

    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            int compare_result = 0;

            if (strcmp(column_choice, "Location") == 0) {
                compare_result = strcmp(hotel[j].location, hotel[j + 1].location);
            } else if (strcmp(column_choice, "City") == 0) {
                compare_result = strcmp(hotel[j].city, hotel[j + 1].city);
            } else if (strcmp(column_choice, "Price") == 0) {
                compare_result = hotel[j].price - hotel[j + 1].price;
            } else if (strcmp(column_choice, "Rooms") == 0) {
                compare_result = hotel[j].room - hotel[j + 1].room;
            } else if (strcmp(column_choice, "Bathroom") == 0) {
                compare_result = hotel[j].bathroom - hotel[j + 1].bathroom;
            } else if (strcmp(column_choice, "Carpark") == 0) {
                compare_result = hotel[j].carpark - hotel[j + 1].carpark;
            } else if (strcmp(column_choice, "Type") == 0) {
                compare_result = strcmp(hotel[j].type, hotel[j + 1].type);
            } else if (strcmp(column_choice, "Furnish") == 0) {
                compare_result = strcmp(hotel[j].furnish, hotel[j + 1].furnish);
            }

            if (compare_result > 0) {
                temp = hotel[j];
                hotel[j] = hotel[j + 1];
                hotel[j + 1] = temp;
            }
        }
    }
}

void bubblesortDES(struct coordinate hotel[], int n, const char *column_choice) {
    int i, j;
    struct coordinate temp;

    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            int compare_result = 0;

            if (strcmp(column_choice, "Location") == 0) {
                compare_result = strcmp(hotel[j].location, hotel[j + 1].location);
            } else if (strcmp(column_choice, "City") == 0) {
                compare_result = strcmp(hotel[j].city, hotel[j + 1].city);
            } else if (strcmp(column_choice, "Price") == 0) {
                compare_result = hotel[j].price - hotel[j + 1].price;
            } else if (strcmp(column_choice, "Rooms") == 0) {
                compare_result = hotel[j].room - hotel[j + 1].room;
            } else if (strcmp(column_choice, "Bathroom") == 0) {
                compare_result = hotel[j].bathroom - hotel[j + 1].bathroom;
            } else if (strcmp(column_choice, "Carpark") == 0) {
                compare_result = hotel[j].carpark - hotel[j + 1].carpark;
            } else if (strcmp(column_choice, "Type") == 0) {
                compare_result = strcmp(hotel[j].type, hotel[j + 1].type);
            } else if (strcmp(column_choice, "Furnish") == 0) {
                compare_result = strcmp(hotel[j].furnish, hotel[j + 1].furnish);
            }

            if (compare_result < 0) {
                temp = hotel[j];
                hotel[j] = hotel[j + 1];
                hotel[j + 1] = temp;
            }
        }
    }
}
void printHeader(){
	printf("| %-20s | %-12s | %-10s | %-5s | %-8s | %-10s | %-12s | %-12s |\n", "Location", "City", "Price", "Rooms", "Bathroom", "Carpark", "Type", "Furnish");
}
void choice_2(FILE* fptr, int rows) {
    char column_choice[100];
    char keyword[100];
    int headerPrinted = 0;
    static int headertable = 1;
    rows = 11;

    printf("Choose Column: ");
    scanf("%s", column_choice);

    printf("What hotel do you want to find? ");
    scanf("%s", keyword);

    int found = 0;

    rewind(fptr);

    char header[256];
    fgets(header, sizeof(header), fptr);

    struct coordinate hotel;

    while (fscanf(fptr, "%[^,],%[^,],%d,%d,%d,%d,%[^,],%[^\n]\n",
                 hotel.location, hotel.city, &hotel.price, &hotel.room, &hotel.bathroom,
                 &hotel.carpark, hotel.type, hotel.furnish) == 8 && !feof(fptr)) {

        if ((strcmp(column_choice, "Location") == 0 && strcmp(hotel.location, keyword) == 0) ||
            (strcmp(column_choice, "City") == 0 && strcmp(hotel.city, keyword) == 0) ||
            (strcmp(column_choice, "Price") == 0 && hotel.price == atoi(keyword)) ||
            (strcmp(column_choice, "Rooms") == 0 && hotel.room == atoi(keyword)) ||
            (strcmp(column_choice, "Bathroom") == 0 && hotel.bathroom == atoi(keyword)) ||
            (strcmp(column_choice, "Carpark") == 0 && hotel.carpark == atoi(keyword)) ||
            (strcmp(column_choice, "Type") == 0 && strcmp(hotel.type, keyword) == 0) ||
            (strcmp(column_choice, "Furnish") == 0 && strcmp(hotel.furnish, keyword) == 0)) {
			
            found = 1;
			
            if (found == 0) {
                printf("No data found.\n");
            }else if (found == 1 && headerPrinted == 0){
            	printHeader();
                headerPrinted = 1;
			}

            printf("| %-20s | %-12s | %-10d | %-5d | %-8d | %-10d | %-12s | %-12s |\n",
                   hotel.location, hotel.city, hotel.price, hotel.room, hotel.bathroom,
                   hotel.carpark, hotel.type, hotel.furnish);
        }
    }

    if (!found) {
        printf("NOT FOUND! : No matching data found.\n");
		}
}

void choice_3(FILE* fptr, struct coordinate hotel[], int rows) {
    char column_choice[100];
    rows = 11;
    int i = 0;
    char choice[20];

    printf("Choose column for sorting: ");
    scanf("%s", column_choice);

    char header[256];
    fgets(header, sizeof(header), fptr);

    for (i = 0; i < feof; i++) {
        if (fscanf(fptr, "%[^,],%[^,],%d,%d,%d,%d,%[^,],%[^\n]\n",
                   hotel[i].location, hotel[i].city, &hotel[i].price,
                   &hotel[i].room, &hotel[i].bathroom, &hotel[i].carpark,
                   hotel[i].type, hotel[i].furnish) != 8) {
            break;
        }
    }

    printf("Ascending or Descending (asc or des): ");
    scanf("%s", choice);

    if (strcmp(choice, "asc") == 0){
        bubblesort(hotel, i, column_choice);

        printf("| %-20s | %-12s | %-10s | %-5s | %-8s | %-10s | %-11s    | %-12s |\n",
               "Location", "City", "Price", "Rooms", "Bathroom", "Carpark", "Type", "Furnish");

        int j;
        for (j = 0; j < rows; j++) {
            printf("| %-20s | %-12s | %-10d | %-5d | %-8d | %-10d | %-12s   | %-12s |\n",
                   hotel[j].location, hotel[j].city, hotel[j].price,
                   hotel[j].room, hotel[j].bathroom, hotel[j].carpark,
                   hotel[j].type, hotel[j].furnish);
        }
    }else if(strcmp(choice, "des") == 0){
    	bubblesortDES(hotel, i, column_choice);

        printf("| %-20s | %-12s | %-10s | %-5s | %-8s | %-10s | %-11s    | %-12s |\n",
               "Location", "City", "Price", "Rooms", "Bathroom", "Carpark", "Type", "Furnish");

        int j;
        for (j = 0; j < rows; j++) {
            printf("| %-20s | %-12s | %-10d | %-5d | %-8d | %-10d | %-12s   | %-12s |\n",
                   hotel[j].location, hotel[j].city, hotel[j].price,
                   hotel[j].room, hotel[j].bathroom, hotel[j].carpark,
                   hotel[j].type, hotel[j].furnish);
		}
    } else{
        printf("Invalid sorting order. Please use 'asc' or 'des'.\n");
    }
}


void exportData(FILE* fp, struct coordinate hotel[], int rows) {
    FILE* exportFile;
    char name[100];
    rows = 11;

    char header[256];
    fgets(header, sizeof(header), fp);

    printf("File Name: ");
    scanf("%[^\n]", name);
    strcat(name, ".csv");

    exportFile = fopen(name, "w");

//    if (exportFile == NULL) {
//        printf("Error creating export file.\n");
//        return;
//    }

    fprintf(exportFile, "%s", header);

    while (fscanf(fp, "%[^,],%[^,],%d,%d,%d,%d,%[^,],%[^\n]\n",
                  hotel[0].location, hotel[0].city, &hotel[0].price,
                  &hotel[0].room, &hotel[0].bathroom, &hotel[0].carpark,
                  hotel[0].type, hotel[0].furnish) == 8) {
        fprintf(exportFile, "%s,%s,%d,%d,%d,%d,%s,%s\n",
                hotel[0].location, hotel[0].city, hotel[0].price,
                hotel[0].room, hotel[0].bathroom, hotel[0].carpark,
                hotel[0].type, hotel[0].furnish);
    }

    printf("Data successfully written to file %s!\n", name);

    fclose(exportFile);
}


int main(){
	struct coordinate hotel[4000];
	FILE* fp;
	fp = fopen("file.csv", "r");
	int choice, rows = 0;
	
	do{
		printf("What do you want to do?\n");
		printf("1. Display data\n");
		printf("2. Search data\n");
		printf("3. Sort data\n");
		printf("4. Export data\n");
		printf("5. Exit\n");
		printf("Your choice: ");
		scanf("%d", &choice);
		getchar();
		switch(choice){
			case 1:
				printf("Number of rows: ");	
				scanf("%d", &rows);
				printf("\n");
				displayData(fp, rows);
				break;
			case 2:
				choice_2(fp, rows);
				break;
			case 3:
				choice_3(fp, hotel, rows);
				break;
			case 4:
				exportData(fp, hotel, rows);
				break;
			case 5:
				system("cls");
				break;
		}
	} while(choice != 5);

	return 0;
	/* 	Function Display data untuk mendisplay data dari data ke 1 sampai baris yang sudah ditentukan
		Function choice_2 / selection data/ search data digunakan untuk mencari data sesuai kolom apabila data yang dicari sesuai dengan key search
	yang dimasukkan maka program akan menampilkan data data yang berhubungan dengan key search tersebut.
		Function choice_3 / sort data adalah function yang digunakan untuk mengurutkan data, namun sebelum diurutkan kita harus mengetik kolom data
	apa yang ingin kita urutkan, selanjutkan kita akan memilih ingin mengurutkan data secara ascending(data terkecil ke data terbesar) atau secara
	descending ( data terbesar ke terkecil), lalu sistem akan menampilkan sebanyak 10 data yang sudah diurutkan sesuai dengan pilihan user.
		Selanjutnya function export data, function ini digunakan untuk mengeksport data dimana nantinya data baru akan ditambahkan ke data lama
	dengan memasukan data dari file lama ke file baru. */
}


